<?php $__env->startSection('content'); ?>
 
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Data Golongan</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    </head>
    <body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <a class="btn btn-success" href="<?php echo e(url('golongan/create')); ?>"> Tambah Data </a>
                        <table class="table table-bordered">
                            <thead>
    <tr>
            <th width="40px"><b>No.</b></th>
                <td>Kode Golongan</td>
                <td>Nama Golongan</td>
            <th width="210px" colspan="2">Action</th>
        </tr>
      </thead>
<?php $no=1;
?>
         <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><b> <?= $no++; ?><b></td>
                    <td><?php echo e($row->gol_kode); ?></td>
                    <td><?php echo e($row->gol_nama); ?></td>
                <td>
            <a href="<?php echo e(url('golongan/' . $row->gol_id . '/edit')); ?>" class="btn btn-primary">Edit</a></td>
<td>                    
                        <form action="<?php echo e(url('golongan/' . $row->gol_id)); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger">Hapus</button>
                        </form>                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</div>
</div>
</div>
</div>

    </div>
    </body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\CRUD-Laravel-9\resources\views/golongan/index.blade.php ENDPATH**/ ?>